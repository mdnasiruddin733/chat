const socket = io();

const messageInput = document.getElementById("messageInput");
const messagesDiv = document.getElementById("messages");

const config = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };
let peerConnection;
let dataChannel;

async function startCall() {
    peerConnection = new RTCPeerConnection(config);
    dataChannel = peerConnection.createDataChannel("chat");

    setupPeerConnection();

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit("offer", offer);
}

async function receiveCall() {
    peerConnection = new RTCPeerConnection(config);
    peerConnection.ondatachannel = (event) => {
        dataChannel = event.channel;
        setupDataChannel();
    };

    setupPeerConnection();
}

function setupPeerConnection() {
    peerConnection.onicecandidate = (event) => {
        if (event.candidate) socket.emit("ice-candidate", event.candidate);
    };

    peerConnection.ondatachannel = (event) => {
        dataChannel = event.channel;
        setupDataChannel();
    };
}

function setupDataChannel() {
    dataChannel.onmessage = (event) => displayMessage(`Peer: ${event.data}`);
}

socket.on("offer", async (offer) => {
    if (!peerConnection) receiveCall();

    await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));

    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    socket.emit("answer", answer);
});

socket.on("answer", async (answer) => {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
});

socket.on("ice-candidate", async (candidate) => {
    await peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
});

function sendMessage() {
    const message = messageInput.value;
    if (message.trim() && dataChannel.readyState === "open") {
        dataChannel.send(message);
        displayMessage(`You: ${message}`);
        messageInput.value = "";
    }
}

function displayMessage(text) {
    const msgElement = document.createElement("p");
    msgElement.textContent = text;
    messagesDiv.appendChild(msgElement);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}
